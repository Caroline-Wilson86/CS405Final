// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> //to use standard error production CEW 3/2021

bool do_even_more_custom_application_logic()
{
    
    try {
        throw "exception";
    }

    catch (std::invalid_argument& e) {

        std::cout << "Running Even More Custom Application Logic." << std::endl;
    }

    return true;
}
void do_custom_application_logic()
{
    throw "exception: 2";

    std::cout << "Running Custom Application Logic." << std::endl;

    if (do_even_more_custom_application_logic())
    {
        std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
    try {
        do_custom_application_logic();
    }

    catch (const std::exception& e) {
        std::cerr << "exception occurred" << std::endl;
        std::cerr << e.what();
        throw;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    //if dividing by zero throw exception CEW 3/2021
    if (den == 0) {
        throw std::invalid_argument("Error: Cannot divide by zero.");
    }

    //else perform division CEW 3/2021
    return (num / den);
} 
void do_division() noexcept
{
    
    float numerator, denominator;
    numerator = 10.0f;
    denominator = 0;

    //try CEW 3/2021
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //catch exception thrown by divide CEW 3/2021
    catch (std::invalid_argument& e) {
        std::cout << "Division Exception" << std::endl << e.what();
    }
}
int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cerr << "Excpetion Occurred" << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Exception Occurred" << e.what() << std::endl;
    }
    catch (...) {
    }

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    do_division();
    do_custom_application_logic();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu